package com.finances.finances.activity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinancesActivityApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinancesActivityApplication.class, args);
	}

}
