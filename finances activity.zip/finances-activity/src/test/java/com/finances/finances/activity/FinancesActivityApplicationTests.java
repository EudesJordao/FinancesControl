package com.finances.finances.activity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinancesActivityApplicationTests {

	@Test
	void contextLoads() {
	}

}
